// Separa uma string de acordo com o caracter separador especificado.

// Exemplo:

    let email = "usuario@exemplo.com";
    let partesEmail = email.split("@");
    console.log("Antes: ",email)
    console.log("Depois: ",partesEmail)